// App external
import React, { PureComponent } from 'react'

// Module internal
//import './Accueil.scss'

interface IProps {}

class TopAuteur extends PureComponent<IProps> {
  public render() {
    return <div className="TopAuteur">{'TopAuteur'}</div>
  }
}

export default TopAuteur
