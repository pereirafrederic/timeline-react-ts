// App external
import React, { PureComponent } from 'react'

// Module internal
//import './Accueil.scss'

interface IProps {}

class TopOeuvre extends PureComponent<IProps> {
  public render() {
    return <div className="TopOeuvre">{'TopOeuvre'}</div>
  }
}

export default TopOeuvre
