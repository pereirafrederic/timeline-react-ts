// App external
import React, { PureComponent } from 'react'

// Module internal
//import './Accueil.scss'

interface IOwnProps {}
interface IProps extends IOwnProps {}

class LecteurSouhaits extends PureComponent<IProps> {
  public render() {
    return <div className="LecteurSouhaits">{'LecteurSouhaits'}</div>
  }
}

export default LecteurSouhaits
