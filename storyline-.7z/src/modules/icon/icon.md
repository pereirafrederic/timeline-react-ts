livre incurve - book-open-variant
livre plat - book-open-outline
livre non fini - notebook
serie non fini - notebook-multiple

script - script
script debuté - script-text

lieu - map-legend

lieu en cours - map-marker-radius

chrono + lieu - map-clock

compte - account-circle
identite - account-card-details

mode auteur - account-convert
auteur page - account-badge-horizontal

coordonne bancaire - bank

next - page-next-outline
prev - page-previous-outline

faire un don - coin

voir commentaire - comment-eye-outline
ajouterun commenaire - comment-plus-outline

statut vu - eye-check-outline
statut en cours - eye-outline
statut pas vu - eye-off-outline

statut souhaité - bullseye
statut acheté - bullseye-arrow

favori -- heart
