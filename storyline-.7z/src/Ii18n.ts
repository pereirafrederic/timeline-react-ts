export default interface Ii18n {
  [key: string]: any
}
