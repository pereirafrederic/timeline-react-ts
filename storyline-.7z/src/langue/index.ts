const lang = 'fr-FR'

export default {
  lang,
}
